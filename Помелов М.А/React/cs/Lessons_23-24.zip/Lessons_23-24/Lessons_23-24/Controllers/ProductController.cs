﻿using Microsoft.AspNetCore.Mvc;

namespace Lessons_23_24.Controllers
{
    [Route("product")]
    public class ProductController : Controller
    {
        [Route("show-all/{category}")] // product/list/electronics
        public IActionResult List(string category)
        {
            //return Content($"Category: {category}");
            return View("List");
        }

        [Route("details/{id}")] // product/details/10
        public IActionResult Details(int id)
        {
            //return Content($"Priduct ID: {id}");
            return View("Details");
        }
    }
}
