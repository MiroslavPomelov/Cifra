﻿using System.ComponentModel.DataAnnotations;

namespace Lessons_25_26.Models
{
    public class Book
    {
        public int Id { get; set; }
        public string Title { get; set; }
        [Required]
        [StringLength(100)]
        public string Author { get; set; }
        [Range(1, 1000)]
        public int Pages { get; set; }
        [DataType(DataType.Date)]
        public DateTime PublicationDate { get; set; }
    }
}
