﻿using System.ComponentModel.DataAnnotations;

namespace Lessons_25_26.Models
{
    public class User
    {
        [Required(ErrorMessage = "Имя обязательно для заполнения")]
        public string Name { get; set; }
        [EmailAddress(ErrorMessage = "Некорректный почтовый адрес")]
        public string Email { get; set; }
        [RegularExpression(@"^\+?\d{10,12}$", ErrorMessage = "Некорректный номер телефона")]
        public string Phone { get; set; }
    }
}
