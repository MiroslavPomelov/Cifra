﻿using Lessons_25_26.Models;

namespace Lessons_25_26.Utils.Extentions
{
    public static class BookExtentions
    {
        //public static void ConvertFromEntity(this Book book, Database.Entities.Book incoming)
        //{
        //    book.Title = incoming.Title;
        //    book.Author = incoming.Author;
        //    book.Pages = incoming.Pages;
        //    book.PublicationDate = incoming.PublicationDate;
        //}
        public static Database.Entities.Book ConvertToEntity(this Book book)
        {
            return new Database.Entities.Book()
            {
                Title = book.Title,
                Author = book.Author,
                Pages = book.Pages,
                PublicationDate = book.PublicationDate
            };
        }
        public static Book ConvertToViewModel(this Database.Entities.Book book)
        {
            return new Book()
            {
                Title = book.Title,
                Author = book.Author,
                Pages = book.Pages,
                PublicationDate = book.PublicationDate
            };
        }

        public static int MultiplyToSome(this int number, int multiplicator)
        {
            return number * multiplicator;
        }
    }
}
