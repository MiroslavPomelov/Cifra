﻿using Lessons_25_26.Database.Entities;
using Microsoft.EntityFrameworkCore;

namespace Lessons_25_26.Database.Contexts
{
    public class SqliteDbContext : DbContext
    {
        public DbSet<Book> Books { get; set; } = null;

        public SqliteDbContext()
        {
            Database.EnsureCreated();
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite("DataSource=database.db");
        }
    }
}
