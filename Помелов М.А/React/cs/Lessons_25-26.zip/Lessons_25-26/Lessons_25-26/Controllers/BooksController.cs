﻿using Lessons_25_26.Database.Contexts;
using Lessons_25_26.Models;
using Lessons_25_26.Utils.Extentions;
using Microsoft.AspNetCore.Mvc;

namespace Lessons_25_26.Controllers
{
    public class BooksController : Controller
    {
        public IActionResult Index()
        {
            List<Book> viewModelBooks = new List<Book>();
            using (SqliteDbContext context = new SqliteDbContext())
            {
                List<Database.Entities.Book> databaseBooks = context.Books.ToList();
                foreach (var databaseBook in databaseBooks)
                {
                    viewModelBooks.Add(databaseBook.ConvertToViewModel());
                }
            }
            return View(viewModelBooks);
        }


        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Book book)
        {
            if (ModelState.IsValid) // То есть модель прошла валидацию
            {
                using (SqliteDbContext context = new SqliteDbContext())
                {
                    context.Books.Add(book.ConvertToEntity());
                    context.SaveChanges();
                }

                return RedirectToAction("Index");
            }
            return View(book);
        }
    }
}
